from django.contrib import admin

from .models import Mentor,TeamMember,Department,Projects

admin.site.register(Mentor)
admin.site.register(TeamMember)
admin.site.register(Department)
admin.site.register(Projects)