from django.apps import AppConfig


class PjsappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pjsapp'
